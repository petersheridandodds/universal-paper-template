#!/bin/sh
echo "creating $1-arxiv.tgz..." 1>&2;
cd package;
tar cvfzph ../$1-arxiv.tgz fig[0-9]*.pdf *revtex4-combined.tex 1>&2;
